# Criador de Senhas

Projeto de gerador de senhas com interface em português.

## Funcionalidades
- Escolha do tamanho da senha (4 a 64 caracteres).
- Seleção de letras maiúsculas, minúsculas, números e símbolos.
- Geração aleatória com `crypto.getRandomValues()`.
- Garantia de pelo menos um caractere de cada categoria selecionada.
- Embaralhamento dos caracteres.
- Opção para mostrar ou ocultar a senha.
- Cópia para a área de transferência.
- Indicador estimado de força da senha.

## Como executar
1. Extraia o arquivo ZIP.
2. Abra a pasta `criador-de-senhas`.
3. Abra `index.html` em um navegador atualizado.
4. Configure as opções e clique em **Gerar senha**.

A cópia pode exigir HTTPS ou localhost, conforme as regras do navegador.

## Arquivos
- `index.html`: estrutura da página.
- `style.css`: estilos e layout responsivo.
- `script.js`: lógica do gerador.
