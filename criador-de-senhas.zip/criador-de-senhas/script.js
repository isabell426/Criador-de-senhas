// ELEMENTOS HTML
const password = document.getElementById("password");
const length = document.getElementById("length");
const lengthValue = document.getElementById("lengthValue");
const lengthOutput = document.getElementById("lengthOutput");

const uppercase = document.getElementById("uppercase");
const lowercase = document.getElementById("lowercase");
const numbers = document.getElementById("numbers");
const symbols = document.getElementById("symbols");

const generateBtn = document.getElementById("generateBtn");
const copyBtn = document.getElementById("copyBtn");
const togglePasswordBtn = document.getElementById("togglePassword");

const message = document.getElementById("message");
const strengthText = document.getElementById("strengthText");
const strengthBar = document.getElementById("strengthBar");

// ATUALIZAR TAMANHO
length.addEventListener("input", () => {
  lengthValue.textContent = length.value;
  lengthOutput.textContent = length.value;
});

// ESCOLHER ÍNDICE ALEATÓRIO SEM VIÉS DE MÓDULO
function randomIndex(max) {
  const range = 0x100000000;
  const limit = Math.floor(range / max) * max;
  const values = new Uint32Array(1);

  do {
    crypto.getRandomValues(values);
  } while (values[0] >= limit);

  return values[0] % max;
}

// EMBARALHAR CARACTERES
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = randomIndex(i + 1);
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// GERAR SENHA
function generatePassword() {
  const size = Number(length.value);
  const characterSets = [];

  if (uppercase.checked) characterSets.push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  if (lowercase.checked) characterSets.push("abcdefghijklmnopqrstuvwxyz");
  if (numbers.checked) characterSets.push("0123456789");
  if (symbols.checked) characterSets.push("!@#$%&*()-_=+?");

  if (characterSets.length === 0) {
    password.value = "";
    message.textContent = "Selecione pelo menos uma opção!";
    strengthText.textContent = "Indisponível";
    strengthBar.style.width = "0%";
    return;
  }

  if (size < characterSets.length) {
    password.value = "";
    message.textContent = "Aumente o tamanho da senha!";
    strengthText.textContent = "Indisponível";
    strengthBar.style.width = "0%";
    return;
  }

  // GARANTIR UM CARACTERE DE CADA CATEGORIA SELECIONADA
  const selectedCharacters = [];
  characterSets.forEach(set => {
    selectedCharacters.push(set[randomIndex(set.length)]);
  });

  const allCharacters = characterSets.join("");

  while (selectedCharacters.length < size) {
    selectedCharacters.push(allCharacters[randomIndex(allCharacters.length)]);
  }

  const finalPassword = shuffle(selectedCharacters).join("");
  password.value = finalPassword;
  password.type = "password";
  togglePasswordBtn.textContent = "◉";
  message.textContent = "Senha gerada com sucesso!";
  checkStrength(finalPassword);
}

// VERIFICAR FORÇA DA SENHA
function checkStrength(value) {
  let score = 0;

  if (value.length >= 12) score++;
  if (/[A-Z]/.test(value)) score++;
  if (/[a-z]/.test(value)) score++;
  if (/[0-9]/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;

  if (score <= 2) {
    strengthText.textContent = "FRACA";
    strengthText.style.color = "#ff6666";
    strengthBar.style.background = "#ff5555";
    strengthBar.style.width = "25%";
  } else if (score <= 3) {
    strengthText.textContent = "MÉDIA";
    strengthText.style.color = "#ffcc55";
    strengthBar.style.background = "#ffcc55";
    strengthBar.style.width = "60%";
  } else {
    strengthText.textContent = "FORTE";
    strengthText.style.color = "#39ff88";
    strengthBar.style.background = "#39ff88";
    strengthBar.style.width = "100%";
  }
}

// COPIAR SENHA
copyBtn.addEventListener("click", async () => {
  if (!password.value) {
    message.textContent = "Gere uma senha primeiro!";
    return;
  }

  try {
    await navigator.clipboard.writeText(password.value);
    message.textContent = "Senha copiada com sucesso!";
  } catch (error) {
    message.textContent = "Não foi possível copiar. Verifique as permissões do navegador.";
  }
});

// MOSTRAR OU OCULTAR SENHA
togglePasswordBtn.addEventListener("click", () => {
  if (!password.value) return;
  const isHidden = password.type === "password";
  password.type = isHidden ? "text" : "password";
  togglePasswordBtn.textContent = isHidden ? "◎" : "◉";
});

// EVENTO DO BOTÃO GERAR
generateBtn.addEventListener("click", generatePassword);

// GERAR UMA SENHA AO ABRIR A PÁGINA
generatePassword();
